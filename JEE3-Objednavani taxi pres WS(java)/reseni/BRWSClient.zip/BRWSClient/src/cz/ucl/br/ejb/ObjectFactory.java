
package cz.ucl.br.ejb;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the cz.ucl.br.ejb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RequestTaxiResponse_QNAME = new QName("http://ejb.br.ucl.cz/", "requestTaxiResponse");
    private final static QName _RequestTaxi_QNAME = new QName("http://ejb.br.ucl.cz/", "requestTaxi");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: cz.ucl.br.ejb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RequestTaxi }
     * 
     */
    public RequestTaxi createRequestTaxi() {
        return new RequestTaxi();
    }

    /**
     * Create an instance of {@link RequestTaxiResponse }
     * 
     */
    public RequestTaxiResponse createRequestTaxiResponse() {
        return new RequestTaxiResponse();
    }

    /**
     * Create an instance of {@link TaxiResponse }
     * 
     */
    public TaxiResponse createTaxiResponse() {
        return new TaxiResponse();
    }

    /**
     * Create an instance of {@link TaxiRequest }
     * 
     */
    public TaxiRequest createTaxiRequest() {
        return new TaxiRequest();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequestTaxiResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ejb.br.ucl.cz/", name = "requestTaxiResponse")
    public JAXBElement<RequestTaxiResponse> createRequestTaxiResponse(RequestTaxiResponse value) {
        return new JAXBElement<RequestTaxiResponse>(_RequestTaxiResponse_QNAME, RequestTaxiResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequestTaxi }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ejb.br.ucl.cz/", name = "requestTaxi")
    public JAXBElement<RequestTaxi> createRequestTaxi(RequestTaxi value) {
        return new JAXBElement<RequestTaxi>(_RequestTaxi_QNAME, RequestTaxi.class, null, value);
    }

}
