
package cz.ucl.br.ejb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for taxiResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="taxiResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="price" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="request" type="{http://ejb.br.ucl.cz/}taxiRequest" minOccurs="0"/>
 *         &lt;element name="taxiDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="taxiName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "taxiResponse", propOrder = {
    "price",
    "request",
    "taxiDescription",
    "taxiName"
})
public class TaxiResponse {

    protected Double price;
    protected TaxiRequest request;
    protected String taxiDescription;
    protected String taxiName;

    /**
     * Gets the value of the price property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPrice(Double value) {
        this.price = value;
    }

    /**
     * Gets the value of the request property.
     * 
     * @return
     *     possible object is
     *     {@link TaxiRequest }
     *     
     */
    public TaxiRequest getRequest() {
        return request;
    }

    /**
     * Sets the value of the request property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxiRequest }
     *     
     */
    public void setRequest(TaxiRequest value) {
        this.request = value;
    }

    /**
     * Gets the value of the taxiDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxiDescription() {
        return taxiDescription;
    }

    /**
     * Sets the value of the taxiDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxiDescription(String value) {
        this.taxiDescription = value;
    }

    /**
     * Gets the value of the taxiName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxiName() {
        return taxiName;
    }

    /**
     * Sets the value of the taxiName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxiName(String value) {
        this.taxiName = value;
    }

}
