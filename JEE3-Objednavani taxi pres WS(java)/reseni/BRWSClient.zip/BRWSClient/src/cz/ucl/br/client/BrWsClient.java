package cz.ucl.br.client;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes.Name;
import java.util.logging.Logger;

import javax.wsdl.extensions.soap.SOAPBody;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;

import cz.ucl.br.ejb.TaxiRequest;
import cz.ucl.br.ejb.TaxiRequestManager;
import cz.ucl.br.ejb.TaxiRequestManagerBeanService;

public class BrWsClient extends CommandLineClient {

	private static final Logger log = Logger.getLogger(BrWsClient.class
			.getName());

	/**
	 * @param args
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 * @throws ClassCastException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		BrWsClient client = new BrWsClient();
		client.doMenu();

	}
	
	
		private void doMenu() throws IOException {
			List<String> choices = new ArrayList<String>();
			choices.add("Interactive taxi request");
			choices.add("Taxi request from a file");
			choices.add("Exit");

			while (true) {
				switch (getChoice("Select an option: ", choices)) {
				case 1:
					doInteractiveRequest();
					break;
				case 2:
					doXmlRequest();
					break;
				case 3:
					System.exit(0);
				}
			}

		}



	private void doInteractiveRequest() {
		
		String clientContact = getInput("Client contact");
		String clientName = getInput("Client name");
		double distance = Double.parseDouble(getInput("Distance"));
		String from = getInput("From");
		String location = getInput("Location");
		String to = getInput("To");
	
       	
		//DOPLNENO kód pro odeslání SOAP požadavku a zobrazení odpovědi (ID požadavku)
		 
		try {
		   TaxiRequest tr = new TaxiRequest();
    	   tr.setClientContact(clientContact);
     	   tr.setClientName(clientName);
     	   tr.setDistance(distance);
     	   tr.setLocation(location);
     	   tr.setFrom(from);
     	   tr.setTo(to);
       
         //sestaveni SOAP a poslani
     	  TaxiRequestManagerBeanService portFactory = new TaxiRequestManagerBeanService(); 
          TaxiRequestManager service = portFactory.getTaxiRequestManagerBeanPort();
       	  
          System.out.println("------------------------\nRecieved reservation number: " + service.requestTaxi(tr) + "\n------------------------");

		} catch (Exception e) {
            System.err.println("Error occurred while sending SOAP Request to Server");
            e.printStackTrace();
        }
       			 		
	}
	
	private void printSOAPResponse(SOAPMessage soapResponse) {
		// TODO Auto-generated method stub
	}

	
	private SOAPMessage createSOAPRequest() {
		// TODO Auto-generated method stub
		return null;
	}


	private void doXmlRequest() throws IOException {
		String fileName = getInput("Enter file name of the request");
		InputStream is = new FileInputStream(fileName);
		
		//DOPLNIT kód pro zpracování XML a odeslání WS požadavku  a zobrazení odpovědi (ID požadavku)
		
		is.close();
	}

}
