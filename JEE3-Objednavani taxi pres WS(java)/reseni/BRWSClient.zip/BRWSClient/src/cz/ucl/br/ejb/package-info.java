@javax.xml.bind.annotation.XmlSchema(namespace = "http://ejb.br.ucl.cz/")
package cz.ucl.br.ejb;
