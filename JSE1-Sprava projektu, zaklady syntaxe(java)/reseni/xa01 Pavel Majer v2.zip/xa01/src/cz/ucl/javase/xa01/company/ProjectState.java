package cz.ucl.javase.xa01.company;

public enum ProjectState {
	WAITING,
    CURRENT,
    DONE
}
