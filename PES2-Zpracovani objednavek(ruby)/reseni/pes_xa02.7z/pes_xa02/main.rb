require_relative "product.rb"
require_relative "store.rb"
require_relative "customer.rb"
require_relative "order.rb"

class Shop
  def initialize(arguments)
    # 1. Overte spravne mnozstvi argumentu. V pripade chyby vyvolejte vyjimku.
    # 2. Ulozte si argumenty do vhodnych promennych pro pozdejsi pouziti
  end

  def load_products
    # 1. Nactete XML soubor s produkty. V pripade problemu (napr. neexistujici soubor) vyvolejte vyjimku.
    # 2. Prochazejte XML soubor a vytvarejte nove objekty tridy Produkt. Nezapomente odchytavat vyjimky.
  end

  def load_store
    @store = Store.new
    # 1. Nactete XML soubor se stavem skladu. V pripade problemu (napr. neexistujici soubor) vyvolejte vyjimku.
    # 2. Prochazejte XML soubor a volejte @store.add_product.
  end

  def load_orders
    @orders = []
    # 1. Nactete XML soubor s objednavkami. V pripade problemu (napr. neexistujici soubor) vyvolejte vyjimku.
    # 2. Prochazejte XML soubor a pro jednotlive objednavky:
    # 2a. Vytvorte novy objekt tridy Order.
    # 2b. Pro jednotlive polozky objednavky vytvorte novy objekt tridy OrderItem a predejte jej metode add_item.
    # 2c. Pridejte objednavku do pole @orders.
  end

  def process_order(order)
    # Zpracujte objednavku.
    # Prochazejte jednolive polozky objednavky a provadejte zadane kontroly.
    # V pripade, ze je vse v poradku, upravte stav skladu volanim @store.sell_product.
    # Nezapomente si ulozit udaje o zakaznikovi.
  end

  def process_orders
    # Zpracujte objednavky. Zde se deje samotna logika programu, ktera je podrobne popsana v zadani.
    # Seradte objednavky dle data a v poradi od nejstarsi je zacnete zpracovavat volanim metody process_order.
  end

  def save_store
    # Projdete produkty v @store a ulozte je do XML souboru.
  end

  def save_customers
    # Projdete zakazniky ziskane ze zpracovanych zakazek a ulozte je do XML souboru.
  end

  def run
    # Doplnte reseni vyjimek.
    load_products
    load_store
    load_orders
    process_orders
    save_store
    save_customers
  end
end

shop = Shop.new(ARGV)
shop.run
