class Store
  attr_reader :products

  def initialize
    @products = {} # asociativni pole, klicem je kod produktu, hodnotou mnozstvi
  end

  def add_product(code, amount)
    # 1. Overte korektnost predanych dat (existence produktu s danym kodem v databazi produktu,
    #    povolene mnozstvi). V pripade chyby vyvolejte vyjimku.
    # 2. Pridejte do asociativniho pole @products pod danym kodem dane mnozstvi.
  end

  def sell_product(code, amount)
    # 1. Overte dostatecne mnozstvi produktu na skladu. V pripade chyby vyvolejte vyjimku.
    # 2. Snizte mnozstvi produktu na skladu o hodnotu amount.
  end
end
