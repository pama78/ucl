class Address
  # Doplnte.
end

class Customer
  # Doplnte.
  def initialize(name, address)
    # Doplnte.
  end
end
