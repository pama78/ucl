class OrderItem
  # Doplnte.
  def initialize(product_code, product_name, price, quantity)
    # Doplnte.
  end
end

class Order
  # Doplnte.
  def initilize(order_number, date, shipping_address, billing_address)
    # Doplnte.
    @items = []
  end

  def add_item(item)
    @items << item
  end
end
