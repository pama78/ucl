class Product
  # Tridni promenna @@products slouzi zaroven jako databaze produktu.
  # Jedna se o asociativni pole, kde klicem je vzdy kod produktu a hodnotou objekt produktu samotny.
  @@products = {}

  attr_reader :code, :name, :price

  def initialize(code, name, price)
    # 1. Overte korektnost dat predanych konstruktoru. V pripade chyby vyvolejte vyjimku.
    # 2. Naplnte instancni promenne.
    # 3. Pridejte self do databaze produktu @@products
  end

  def Product.get(code)
    return @@products[code]
  end
end
