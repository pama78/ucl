package com.sun.faces.config;

public class ConfigureListener {

	public ConfigureListener() {
		// TODO Auto-generated constructor stub
	}

}
