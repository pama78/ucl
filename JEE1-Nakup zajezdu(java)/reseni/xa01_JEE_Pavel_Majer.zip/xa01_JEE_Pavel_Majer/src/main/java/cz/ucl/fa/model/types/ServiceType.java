package cz.ucl.fa.model.types;

public enum ServiceType {
	Trip, Spa, Other
}
