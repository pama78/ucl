package cz.ucl.fa.model.types;

public enum TransportationType {
	Airplane, Bus, Train, Combined
}
