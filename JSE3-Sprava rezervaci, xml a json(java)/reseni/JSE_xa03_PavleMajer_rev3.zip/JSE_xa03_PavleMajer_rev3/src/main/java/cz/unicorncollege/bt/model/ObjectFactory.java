package cz.unicorncollege.bt.model;

public class ObjectFactory {

}
