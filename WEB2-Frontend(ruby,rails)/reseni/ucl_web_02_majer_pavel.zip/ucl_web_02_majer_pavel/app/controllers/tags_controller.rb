class TagsController < ApplicationController
  def new
  end

  def create
  end

  def index
    @tags = Tag.all
  end
end
