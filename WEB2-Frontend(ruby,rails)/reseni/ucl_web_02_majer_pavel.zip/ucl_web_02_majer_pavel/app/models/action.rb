class Action < ActiveRecord::Base
end
