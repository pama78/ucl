# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)


#helpers
  #Subject.delete_all;
  #Tag.delete_all;
  #Enterprise.delete_all;
  #Tagging.delete_all;
  #variables  ##returns array http://stackoverflow.com/questions/27021036/undefined-method-id-for-activerecordrelation
  #subjPa=Subject.where(:name=>"PA").first ;
  #Subjects cre  subPa=

#Subjects create
 subjPa=Subject.where(:name => 'PA').first_or_create!
 subjWeb=Subject.where(:name => 'WEB').first_or_create!
 subjOad=Subject.where(:name => 'OAD').first_or_create!
 subjMae=Subject.where(:name => 'MAE').first_or_create!
 subjMat=Subject.where(:name => 'MAT2').first_or_create!
 SubjWeb=Subject.where(:name => 'WEB').first_or_create!
 subjJse=Subject.where(:name => 'JSE').first_or_create!
 subjGal=Subject.where(:name => 'GAL').first_or_create!
 subjEng=Subject.where(:name => 'ENG3').first_or_create!

#Tags create
  tagDu=Tag.where(:name => 'DU').first_or_create!
  tagTest=Tag.where(:name => 'Test').first_or_create!
  tagNearpod=Tag.where(:name => 'Nearpod').first_or_create!
  tagPaper=Tag.where(:name => 'Tužka-Papír').first_or_create!
  tagZkouska=Tag.where(:name => 'Zkouška').first_or_create!
  tagNemamPrubezne=Tag.where(:name => 'Nemám průběžné').first_or_create!
  tagChybiBody=Tag.where(:name => 'V Systému chybí body').first_or_create!

### PA
  e=Enterprise.where(:subject=>subjPa, :title=>'Test1', :text=>'Test z kapitol 1-3' , :is_active=>false, :max_points=>20 , :deadline_at=>DateTime.parse('25/10/2016 20:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

  e=Enterprise.where(:subject=>subjPa, :title=>'Test2', :text=>'Test z kapitol 4-6' , :is_active=>false, :max_points=>30 , :deadline_at=>DateTime.parse('15/11/2016 20:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

  e=Enterprise.where(:subject=>subjPa, :title=>'Semestrálka - autíčko', :text=>'Autíčko arduino, které jezdí samo a vyhybá se překážkám' , :is_active=>true, :max_points=>50 , :deadline_at=>DateTime.parse('18/12/2016 18:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!


### Web
  e=Enterprise.where(:subject=>subjWeb, :title=>'DU1', :text=>'Landpage' , :is_active=>false, :max_points=>10 , :deadline_at=>DateTime.parse('14/11/2016 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjWeb, :title=>'DU2', :text=>'Frontend' , :is_active=>false, :max_points=>10 , :deadline_at=>DateTime.parse('18/12/2016 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjWeb, :title=>'DU3', :text=>'Backend' , :is_active=>true, :max_points=>50 , :deadline_at=>DateTime.parse('8/1/2017 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjWeb, :title=>"Test 1", :text=>"Test z prvních dvou tutoriálů" , :is_active=>false, :max_points=>30 , :deadline_at=>DateTime.parse('11/12/2016 17:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

  e=Enterprise.where(:subject=>subjWeb, :title=>"Test 1-náhradní", :text=>"Náhradní test" , :is_active=>true, :max_points=>30 , :deadline_at=>DateTime.parse('14/01/2017 13:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

### OAD
  e=Enterprise.where(:subject=>subjOad, :title=>"DU1", :text=>"Semestralka kapitoly 1-3" , :is_active=>false, :max_points=>15 , :deadline_at=>DateTime.parse('12/11/2016 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjOad, :title=>"DU2", :text=>"Semestralka kapitoly 4-6" , :is_active=>true, :max_points=>25 , :deadline_at=>DateTime.parse('2/1/2017 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjOad, :title=>"DU3", :text=>"Semestralka final" , :is_active=>true, :max_points=>40 , :deadline_at=>DateTime.parse('9/1/2017 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjOad, :title=>"Test", :text=>"Test z celé látky" , :is_active=>true, :max_points=>20 , :deadline_at=>DateTime.parse('7/1/2017 17:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

  e=Enterprise.where(:subject=>subjOad, :title=>"Test-náhradní", :text=>"Test z celé látky - náhradní termín" , :is_active=>true, :max_points=>20 , :deadline_at=>DateTime.parse('14/1/2017 17:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

#MAKRO
  e=Enterprise.where(:subject=>subjMae, :title=>"Test 1", :text=>"Test kapitoly 1-3" , :is_active=>false, :max_points=>30 , :deadline_at=>DateTime.parse('13/11/2016 16:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagNearpod.id).first_or_create!

  e=Enterprise.where(:subject=>subjMae, :title=>"Test 2", :text=>"Test kapitoly 4-6" , :is_active=>false, :max_points=>30 , :deadline_at=>DateTime.parse('11/12/2016 16:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagNearpod.id).first_or_create!

  e=Enterprise.where(:subject=>subjMae, :title=>"Test 3", :text=>"Test kapitoly 1-10" , :is_active=>true, :max_points=>100 , :deadline_at=>DateTime.parse('08/01/2017 16:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagNearpod.id).first_or_create!

#MAT
  e=Enterprise.where(:subject=>subjMat, :title=>"DU 1", :text=>"DU 1" , :is_active=>false, :max_points=>10 , :deadline_at=>DateTime.parse('21/11/2016 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjMat, :title=>"DU 2", :text=>"DU 2" , :is_active=>false, :max_points=>10 , :deadline_at=>DateTime.parse('21/11/2016 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjMat, :title=>"Test 1", :text=>"Test kapitoly 1-4" , :is_active=>false, :max_points=>40 , :deadline_at=>DateTime.parse('12/11/2016 16:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

  e=Enterprise.where(:subject=>subjMat, :title=>"Test 2", :text=>"Test kapitoly 5-10" , :is_active=>true, :max_points=>40 , :deadline_at=>DateTime.parse('07/01/2017 16:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

  e=Enterprise.where(:subject=>subjMat, :title=>"Test 2 náhradní", :text=>"Test kapitoly 5-10 náhradní" , :is_active=>true, :max_points=>40 , :deadline_at=>DateTime.parse('27/01/2017 16:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!


#JSE
  e=Enterprise.where(:subject=>subjJse, :title=>"DU 1", :text=>"DU 1" , :is_active=>false, :max_points=>10 , :deadline_at=>DateTime.parse('13/11/2016 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjJse, :title=>"DU 2", :text=>"DU 2" , :is_active=>false, :max_points=>15 , :deadline_at=>DateTime.parse('27/11/2016 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjJse, :title=>"DU 3", :text=>"DU 3" , :is_active=>true, :max_points=>25 , :deadline_at=>DateTime.parse('18/12/2016 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjJse, :title=>"DU 4", :text=>"DU 4" , :is_active=>true, :max_points=>30 , :deadline_at=>DateTime.parse('22/01/2017 23:59')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

  e=Enterprise.where(:subject=>subjJse, :title=>"Test", :text=>"Souhrnný test" , :is_active=>true, :max_points=>20 , :deadline_at=>DateTime.parse('08/01/2017 16:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagNearpod.id).first_or_create!

  e=Enterprise.where(:subject=>subjJse, :title=>"Test-náhradní", :text=>"Souhrnný test-náhradní" , :is_active=>true, :max_points=>20 , :deadline_at=>DateTime.parse('21/01/2017 16:00')  ).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
  Tagging.where(:enterprise_id => e.id, :tag_id => tagNearpod.id).first_or_create!


#Gal
e=Enterprise.where(:subject=>subjGal, :title=>"DU 1", :text=>"DU 1" , :is_active=>false, :max_points=>10 , :deadline_at=>DateTime.parse('30/11/2016 23:59')  ).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

e=Enterprise.where(:subject=>subjGal, :title=>"DU 2", :text=>"DU 2" , :is_active=>true, :max_points=>20 , :deadline_at=>DateTime.parse('21/12/2016 23:59')  ).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

e=Enterprise.where(:subject=>subjGal, :title=>"DU 3", :text=>"DU 3" , :is_active=>true, :max_points=>30 , :deadline_at=>DateTime.parse('16/1/2017 23:59')  ).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

e=Enterprise.where(:subject=>subjGal, :title=>"Test", :text=>"Souhrnný test" , :is_active=>true, :max_points=>40 , :deadline_at=>DateTime.parse('07/01/2017 16:00')  ).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

e=Enterprise.where(:subject=>subjGal, :title=>"Test-náhradní", :text=>"Souhrnný test-náhradní" , :is_active=>true, :max_points=>40 , :deadline_at=>DateTime.parse('21/01/2017 16:00')  ).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!


#ENG3
e=Enterprise.where(:subject=>subjEng, :title=>"DU 1", :text=>"DU 1" , :is_active=>false, :max_points=>20 , :deadline_at=>DateTime.parse('30/10/2016 23:59')  ).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagDu.id).first_or_create!

e=Enterprise.where(:subject=>subjEng, :title=>"Test", :text=>"Souhrnný test" , :is_active=>true, :max_points=>100 , :deadline_at=>DateTime.parse('11/01/2017 16:00')  ).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!

e=Enterprise.where(:subject=>subjEng, :title=>"Test-náhradní", :text=>"Souhrnný test-náhradní" , :is_active=>true, :max_points=>100 , :deadline_at=>DateTime.parse('21/01/2017 16:00')  ).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagTest.id).first_or_create!
Tagging.where(:enterprise_id => e.id, :tag_id => tagPaper.id).first_or_create!




