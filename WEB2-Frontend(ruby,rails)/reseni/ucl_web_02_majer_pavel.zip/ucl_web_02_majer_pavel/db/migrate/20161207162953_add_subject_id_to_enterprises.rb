class AddSubjectIdToEnterprises < ActiveRecord::Migration
  def change
    add_reference :enterprises, :subject, index: true, foreign_key: true
  end
end
