module Admin::EnterprisesHelper
end
