# == Schema Information
#
# Table name: taggings
#
#  id            :integer          not null, primary key
#  enterprise_id :integer
#  tag_id        :integer
#  created_at    :datetime         not null
#  updated_at    :datetime         not null
#
# Indexes
#
#  index_taggings_on_enterprise_id  (enterprise_id)
#  index_taggings_on_tag_id         (tag_id)
#

class Tagging < ActiveRecord::Base
  belongs_to :enterprise
  belongs_to :tag
 # accepts_nested_attributes_for :enterprise
 # accepts_nested_attributes_for :tag
end
