class Admin::EnterprisesController < Admin::AdminsController
  before_action :set_enterprise, only: [:show, :edit, :update, :destroy, :delete]

  def index
    puts "tag #{:tag}"
    puts "adminenterprises: #{@admin_enterprises}"

    if params[:tag] != nil
      @admin_enterprises = Enterprise.includes(:tags).where(:tags => {:id => params[:tag]}).order(:deadline_at)
      @showType='tag ' + Tag.where(:id => params[:tag]).first.name
    elsif params[:subject] != nil
      @admin_enterprises = Enterprise.includes(:subject).where(:subject => params[:subject]).order(:deadline_at)
      @showType='předmět ' + Subject.where(:id => params[:subject]).first.name
    else
      @admin_enterprises =  Enterprise.all.order(:deadline_at)
      @showType='all'
    end
  end

  def show
    admin_enterprise_path [@enterprise.id]
  end

  # GET /enterprises/new
  def new
    @enterprise = Enterprise.new
  end

  # GET /enterprises/1/edit
  def edit
  end

  # POST /enterprises
  # POST /enterprises.json
  def create
    @enterprise = Enterprise.new(enterprise_params)

    respond_to do |format|
      if @enterprise.save
       # format.html { redirect_to @enterprise, notice: 'Enterprise was successfully created.' }
        format.html { redirect_to  admin_enterprise_path [@enterprise.id], notice: 'Enterprise was successfully created.' }
        format.json { render :show, status: :created, location: @enterprise }
      else
        format.html { render :new }
        format.json { render json: @enterprise.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /enterprises/1
  # PATCH/PUT /enterprises/1.json
  def update
    respond_to do |format|
      if @enterprise.update(enterprise_params)
       # format.html { redirect_to @enterprise, notice: 'Enterprise was successfully updated.' }
        format.html { admin_enterprise_path [@enterprise.id], notice: 'Enterprise was successfully updated.' }
        format.json { render :show, status: :ok, location: @enterprise }
      else
        format.html { render :edit }
        format.json { render json: @enterprise.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /enterprises/1
  # DELETE /enterprises/1.json
  def destroy
    @enterprise.destroy
    respond_to do |format|
      #format.html { redirect_to enterprises_url, notice: 'Enterprise was successfully destroyed.' }
      format.html { redirect_to admin_enterprises_url, notice: 'Enterprise was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_enterprise
    @enterprise = Enterprise.find(params[:id])
  end

  # White list, update here if new params are added
  def enterprise_params
    #params.require(:enterprise).permit(:deadline_at, :title, :text, :is_active, :max_points , :subject_id, :tags, :tag_ids)
    params.require(:enterprise).permit(:deadline_at, :title, :text, :is_active, :max_points , :subject_id, tag_ids: [])

  end
end



