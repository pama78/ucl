class Admin::TagsController < Admin::AdminsController
  #before_filter :login_required
  def new
  end

  def create
  end

  def index
    @admin_tags = Tag.all
    @admin_tags_count = Tag.count
  end
end
