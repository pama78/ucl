# gal_template_project
