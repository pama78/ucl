class Array
  def hrabisort!(ktype = 1)
    #
    # ...
    #
    return self
  end
end
