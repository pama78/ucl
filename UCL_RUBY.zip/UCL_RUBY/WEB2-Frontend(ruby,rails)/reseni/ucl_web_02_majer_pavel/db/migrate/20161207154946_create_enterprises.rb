class CreateEnterprises < ActiveRecord::Migration
  def change
    create_table :enterprises do |t|
      t.datetime :deadline_at
      t.string :title
      t.text :text
      t.boolean :is_active
      t.integer :max_points
      t.timestamps null: false
    end
  end
end
