class Admin::SubjectsController < Admin::AdminsController
  #before_filter :login_required
  def new
    @admin_subject = Subject.new
  end

  def create
  end

  def index
    @admin_subjects = Subject.all
  end
end
