#include ActionController::HttpAuthentication::Basic::ControllerMethods

class Admin::DashboardController < Admin::AdminsController
 #before_filter :login_required

  def index

    #    http://stackoverflow.com/questions/14374580/doing-a-http-basic-authentication-in-rails
    #    http_basic_authenticate_with name: "admin", password: "hunter2"
    #  http_basic_authenticate_with name: "admin", password: "hunter2"

    ##>>    NoMethodError in Admin::DashboardController#index
    ##undefined method `http_basic_authenticate_with' for #<Admin::DashboardController:0x9610e60>


    @admin_enterprises_count = Enterprise.count
    @admin_subjects_count = Subject.count
    @admin_tags_count = Tag.count


    #layout 'admin'
  end
end