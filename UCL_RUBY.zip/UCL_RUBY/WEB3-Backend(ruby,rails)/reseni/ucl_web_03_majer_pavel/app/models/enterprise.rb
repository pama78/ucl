# == Schema Information
#
# Table name: enterprises
#
#  id          :integer          not null, primary key
#  deadline_at :datetime
#  title       :string
#  text        :text
#  is_active   :boolean
#  max_points  :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  subject_id  :integer
#
# Indexes
#
#  index_enterprises_on_subject_id  (subject_id)
#

class Enterprise < ActiveRecord::Base
  belongs_to :subject
  #, :class_name => "", :foreign_key => ""

  has_many :taggings
  has_many :tags, through: :taggings

  validates :title, presence: true
  validates :subject_id, presence: true
  validates_inclusion_of :max_points, :in => 1..100

end
