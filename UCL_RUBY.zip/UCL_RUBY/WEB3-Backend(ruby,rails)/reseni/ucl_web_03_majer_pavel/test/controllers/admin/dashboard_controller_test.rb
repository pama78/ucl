require 'test_helper'

class Admin::DashboardControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
